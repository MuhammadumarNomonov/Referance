package com.example.referance.DB

import com.example.referance.models.Sotuvchi
import com.example.referance.models.Xaridor

interface MyDbIntarface {

    fun addSotuvchi(sotuvchi: Sotuvchi)
    fun getSotuvchi():List<Sotuvchi>
    fun addXaridor(xaridor: Xaridor)
    fun getXaridor():List<Xaridor>

}