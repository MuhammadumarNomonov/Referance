package com.example.referance.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.example.referance.databinding.FragmentSotuvchiXaridorBinding
import com.example.referance.databinding.ItemDialogBinding
import com.example.referance.models.Sotuvchi

class SotuvchiFragment : Fragment() {
    private val binding by lazy { FragmentSotuvchiXaridorBinding.inflate(layoutInflater) }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding.btnAdd.setOnClickListener {
            adding()
        }

        return binding.root
    }

    fun adding() {

        val dialog = AlertDialog.Builder(binding.root.context)
        val itemDialogBinding = ItemDialogBinding.inflate(layoutInflater)

        itemDialogBinding.btnSave.setOnClickListener {
            val sotuvchi : Sotuvchi(


            )
        }

        dialog.setView(itemDialogBinding.root)

        dialog.show()
    }
}
