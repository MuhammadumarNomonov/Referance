package com.example.referance.DB


import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.referance.models.Sotuvchi
import com.example.referance.models.Xaridor

class MyDataBase(context: Context) : SQLiteOpenHelper(context,"Mahsulot_db", null,1),MyDbIntarface{
    override fun onCreate(p0: SQLiteDatabase?) {
       val query = "create table Sotuchi_table (id intager not null primary key autoincrement unique, name not null) "
      p0?.execSQL(query)

    }


    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
    }

    override fun addSotuvchi(sotuvchi: Sotuvchi) {
       val database = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put("name", sotuvchi.name)
        contentValues.put("number",sotuvchi.number)
        database.insert("Sotuchi_table", null,contentValues)
      database.close()
    }

    override fun getSotuvchi(): List<Sotuvchi> {
        val list = mutableListOf<Sotuvchi>()
        val database = this.readableDatabase
        val query = "select * from salom_table"
        val cursor = database.rawQuery(query,null)
         if (cursor.moveToFirst()){
             do {
                 val sotuvchi = Sotuvchi(
                     cursor.getInt(0),
                     cursor.getString(1),
                     cursor.getString(2)
                 )
                 list.add(sotuvchi)
             }while (cursor.moveToNext())
         }
        return list
    }

    override fun addXaridor(xaridor: Xaridor) {
     val database = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put("name",xaridor.name)
        contentValues.put("number",xaridor.number)
        contentValues.put("adress",xaridor.adress)
        database.insert("Sotuchi_table", null,contentValues)
        database.close()
    }

    override fun getXaridor(): List<Xaridor> {
        val list = mutableListOf<Xaridor>()
        val database = this.readableDatabase
        val query = "select * from Sotuchi_table"
        val cursor = database.rawQuery(query, null)
        if (cursor.moveToFirst()) {
            do {
                val xaridor = Xaridor(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3)
                )
                list.add(xaridor)
            } while (cursor.moveToNext())
        }

    return list
    }
}

